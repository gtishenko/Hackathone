self.__precacheManifest = [
  {
    "revision": "35b1d4a7ab7d7bccff35",
    "url": "/static/css/main.7fe6ca95.chunk.css"
  },
  {
    "revision": "35b1d4a7ab7d7bccff35",
    "url": "/static/js/main.91eda22b.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "aae81685afe6ecf797f5",
    "url": "/static/css/2.9d2b281e.chunk.css"
  },
  {
    "revision": "aae81685afe6ecf797f5",
    "url": "/static/js/2.79f8ff27.chunk.js"
  },
  {
    "revision": "9fc223d854470d474fab6a03c3361537",
    "url": "/static/media/dark1.9fc223d8.png"
  },
  {
    "revision": "991028191da3ad6ae11e0b191d78c17d",
    "url": "/static/media/light1.99102819.png"
  },
  {
    "revision": "fa74490a02bd5a3be911856c0865727c",
    "url": "/index.html"
  }
];